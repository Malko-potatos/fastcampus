// 데이터베이스나 API와 같은 외부 데이터 소스와의 통신을 담당합니다.
// import 'package:my_app/service/network_service.dart';

// class RemoteDataSource {
//   final NetworkService networkService;

//   RemoteDataSource(this.networkService);

//   Future<String> fetchData() async {
//     return await networkService.get('https://api.example.com/data');
//   }
// }
