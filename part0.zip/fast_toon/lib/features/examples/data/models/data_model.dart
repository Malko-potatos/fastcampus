// 모델 클래스입니다. 외부 데이터 소스에서 받아오는 데이터를 나타내며, JSON과의 변환 로직을 포함합니다.
// class DataModel {
//   final String data;

//   DataModel(this.data);

//   factory DataModel.fromJson(Map<String, dynamic> json) {
//     return DataModel(json['data']);
//   }

//   Map<String, dynamic> toJson() {
//     return {'data': data};
//   }
// }
