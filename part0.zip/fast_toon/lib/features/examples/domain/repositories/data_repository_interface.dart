// 리포지토리 인터페이스입니다. 
// import 'package:my_app/features/extra_service/domain/entities/data_entity.dart';

// abstract class IDataRepository {
//   Future<DataEntity> getData();
// }
