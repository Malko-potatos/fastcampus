// 유스케이스 클래스입니다. 특정 비즈니스 규칙을 구현합니다. 여기서는 데이터를 가져오는 기능을 구현합니다.

// class FetchDataUseCase {
//   final IDataRepository repository;

//   FetchDataUseCase(this.repository);

//   Future<DataEntity> execute() async {
//     return await repository.getData();
//   }
// }
