// 엔티티 클래스입니다. 도메인 계층에서 사용되는 핵심 데이터 구조를 정의합니다.
// class DataEntity {
//   final String value;

//   DataEntity(this.value);
// }