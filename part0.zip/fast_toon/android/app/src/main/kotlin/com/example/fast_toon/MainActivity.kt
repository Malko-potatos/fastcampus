package com.example.fast_toon

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
